import java.util.Random;
import java.util.Scanner;


class RockPaperScissors
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int num;
        String userInput = "";
        String computerInput = "";
        int userWins = 0;
        int computerWins = 0;

        System.out.println("How many rounds would you like to play?");
        int rounds = Integer.parseInt(sc.nextLine());
        for(int i=0;i<rounds;i++)
        {
            System.out.print("Rock or Paper or Scissors ? ");

            userInput = sc.nextLine();

            // Computer Input
            num = rand.nextInt(3);

            if(num == 0)
            {
                computerInput = "Rock";
            }
            else if(num == 1)
            {
                computerInput = "Paper";
            }
            else if(num == 2)
            {
                computerInput = "Scissors";
            }
            // Computer Choice
            if(computerInput.equals("Scissors"))
            {
                System.out.println("The computer chose scissors.");
            }

            else if(computerInput.equals("Rock"))
            {
                System.out.println("The computer chose rock.");
            }

            else if(computerInput.equals("Paper"))
            {
                System.out.println("The computer chose paper.");
            }

            // Result
            if(userInput.equals("Rock") && computerInput.equals("Scissors"))
            {
                System.out.println("User Wins");
                userWins++;
            }

            else if(userInput.equals("Paper") && computerInput.equals("Rock"))
            {
                System.out.println("User Wins");
                userWins++;
            }

            else if(userInput.equals("Scissors") && computerInput.equals("Paper"))
            {
                System.out.println("User Wins");
                userWins++;
            }

            else if(userInput.equals("Scissors") && computerInput.equals("Rock"))
            {
                System.out.println("Computer Wins");
                computerWins++;
            }

            else if(userInput.equals("Rock") && computerInput.equals("Paper"))
            {
                System.out.println("Computer Wins");
                computerWins++;
            }

            else if(userInput.equals("Paper") && computerInput.equals("Scissors"))
            {
                System.out.println("Computer Wins");
                computerWins++;
            }

            else if(userInput.equals(computerInput))
            {
                System.out.println("Draw");
            }
            System.out.println("User Wins: " + userWins + " Computer Wins: " + computerWins);
        }

        // Overall Winner
        if(userWins > computerWins)
        {
            System.out.println("User wins overall.");
        }
        else if (userWins < computerWins)
        {
            System.out.println("Computer wins overall.");
        }
        else
        {
            System.out.println("The game is a tie.");
        }
    }
}